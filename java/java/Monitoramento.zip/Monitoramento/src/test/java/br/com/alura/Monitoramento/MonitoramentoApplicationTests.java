package br.com.alura.Monitoramento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonitoramentoApplicationTests {

	@Test
	void contextLoads() {
	}

}
