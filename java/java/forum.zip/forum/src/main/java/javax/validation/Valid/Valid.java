package javax.validation.Valid;

public @interface Valid {

}
