package javax.validation.constraints;

public @interface NotNull {

}
