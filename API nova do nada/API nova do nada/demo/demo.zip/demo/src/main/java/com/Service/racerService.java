package com.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import com.Dto.racersDto;
import com.model.racers;
import com.repository.racersRepository;

public class racerService {


    private final racersRepository repository;
    private Long number;

    
    public racerService(racersRepository repository) {
        this.repository = repository;
    }

    // POST
    public racersDto createRacer(racersDto dados2) {
        racers toSaveRacer = new racers(dados2);
        final String team = (dados2.setTeam());
        toSaveRacer.setTeam(team);
        racersDto dados = new racersDto(toSaveRacer.getName(), toSaveRacer.getTeam());
        racers savedRacer = repository.save(toSaveRacer);
        return dados;
    }

     

	public List<racersDto> findAllRacers() {
		return repository.findbyNumber(number).stream()
		.map(racers -> new racersDTO(racers.getName, racers.getNumber())).collect(Collectors.toList());
  }


  // PUT
	public racersDto updateRacer(racersDto dados2, Long number) {
		racers updatedRacers = new racers(dados2);
		racers toUpdateRacers = repository.findbyNumber(racers.getNumber);

		if (dados2.getName() != null) {
			toUpdateRacers.name = dados2.getName();
		}

		if (dados2.getTeam() != null) {
			toUpdateRacers.team = dados2.getTeam();
		}

		racersDto dados = new racersDto(updatedRacers.getName(), updatedRacers.getTeam());
		return dados;
	}

     // DELETE
	public void deleteRacer(Long number) {
		repository.deleteByNumber(number);
	}


    // UTIL
	private List<racersDto> converterListRacerToListRacerDto(List<racers> pilotos) {

		List<racersDto> dtos = new ArrayList<>();

		for (racers racers : pilotos) {
			racersDto racersDTO = new racersDto(racers.getName(), racers.getTeam());
			dtos.add(racersDTO);
		}
		return dtos;
	}

}
