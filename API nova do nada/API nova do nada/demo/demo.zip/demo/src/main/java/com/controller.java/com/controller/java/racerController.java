import java.util.List;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Dto.racersDto;
import com.Service.racerService;
import com.model.racers;



public class racerController {
    
    @RestController
@RequestMapping("pilotos")
public class ExerciciosController {

	private final racerService service;

	public ExerciciosController(racerService service) {
        this.service = service;
    }

    
    @GetMapping
	public List<racersDto> listar() {
		return service.findAllRacers();
	}

	@PostMapping
	@Transactional
	public void cadastrar(@RequestBody racersDto dados) {
		service.createRacer(dados);
	}

	@PutMapping("/{number}")
	@Transactional
	public racersDto atualizar(@RequestBody racersDto dados, @PathVariable Long id) {
		return service.updateRacer(dados, racers.getNumber);
	}

	@DeleteMapping("/{number}")
	@Transactional
	public void deletar(@PathVariable Long number) {
		service.deleteRacer(number);
	}
}
}
