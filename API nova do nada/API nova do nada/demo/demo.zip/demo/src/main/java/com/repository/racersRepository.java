package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.model.racers;

public interface racersRepository extends JpaRepository<racers, Long> {

    racers findbyNumber(Long number);

    void deleteByNumber(Long number);
}
