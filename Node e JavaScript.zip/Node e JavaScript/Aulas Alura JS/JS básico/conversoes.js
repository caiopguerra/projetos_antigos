// tipo de dado 
// booleanos 

// conversão implícita
const numero = 456;
const numeroString = Number("456a");

//Number()
//String()
console.log(numero + numeroString)

// conversão explícita

console.warn(new Error('oi'))