const idadeMinima = 18;
const idadeCliente = 16;

if (idadeCliente >= idadeMinima) {
  console.log("cerveja")
} else {
  console.log("suco")
}
console.log(idadeCliente >= idadeMinima ? "cerveja" : "suco")