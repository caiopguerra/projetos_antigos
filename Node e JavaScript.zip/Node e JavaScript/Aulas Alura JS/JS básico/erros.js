const numero = 1;
// const minhaVar = "oi";
console.log(minhaVar);