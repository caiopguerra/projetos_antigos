// tipo number

const meuNumero = 3;

const primeiroNum = 1;
const segundoNum = 2;



const operacao = primeiroNum * segundoNum;

console.log(operacao)