package br.com.poo.contas;

public class ContaCorrente extends Conta {
	
}
