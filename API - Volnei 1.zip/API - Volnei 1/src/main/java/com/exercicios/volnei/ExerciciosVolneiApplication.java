package com.exercicios.volnei;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExerciciosVolneiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExerciciosVolneiApplication.class, args);
	}

}
