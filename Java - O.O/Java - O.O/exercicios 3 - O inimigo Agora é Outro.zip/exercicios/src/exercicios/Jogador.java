package exercicios;

public class Jogador extends Pessoa {

	private String chuteira;
	private String meiao;
	private String bola;
	
	public String getChuteira() {
		return chuteira;
	}
	public void setChuteira(String chuteira) {
		this.chuteira = chuteira;
	}
	public String getMeiao() {
		return meiao;
	}
	public void setMeiao(String meiao) {
		this.meiao = meiao;
	}
	public String getBola() {
		return bola;
	}
	public void setBola(String bola) {
		this.bola = bola;
	}
	@Override
	public String toString() {
		return "Jogador [chuteira=" + chuteira + ", meiao=" + meiao + ", bola=" + bola + "]";
	}
}
