package exercicios;

import java.util.ArrayList;
import java.util.List;

public class TestaAgenda extends Agenda {
	
	public static void main(String[] args) {
		Agenda agenda = new Agenda();
		agenda.setEvent("feira das profissões");
		agenda.setDateBegin(19.08);
        Pessoa caio = new programador();
        caio.setNome("Caio");
        caio.setIdade(17);
        caio.setAltura(1.76);
        
        Pessoa carlos = new Jogador();
        carlos.setNome("Carlos");
        carlos.setIdade(21);
        carlos.setAltura(1.80);

		agenda.adicionaPessoa(caio.getNome(), caio.getIdade(), caio.getAltura());
		agenda.adicionaPessoa(carlos.getNome(), carlos.getIdade(), carlos.getAltura());

		agenda.imprimeAgenda(caio.getNome());
		agenda.imprimeAgenda(carlos.getNome());
		
		System.out.println(agenda.getEvent());
		System.out.println(agenda.getDateBegin());
	}
}
