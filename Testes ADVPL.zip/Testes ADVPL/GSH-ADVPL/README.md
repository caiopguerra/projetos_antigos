# GSH: ADVPL

![Logo da GSH](./assets/gsh.png)

<h3 align="center">
  Exemplos e Projetos básicos em ADVPL
</h3>

## :computer: Sobre o repositório

Atualmente existem três pastas neste repositório com alguns exemplos de implementação da linguagem ADVPL.

Basicamente se dividem em:

- **Exemplos**
- **Projetos**
- **Testes**

### #️⃣ Exemplos
Contém instruções básicas, principalmente ligadas a lógica de programação e algumas outras instruções para a criação de uma algoritmo básico dem ADVPL.

### 📝 Projetos
Contém exemplos mais complexos, como a criação de um CRUD completo consumindo a database através dos Protheus.

### 🧪 Testes
Contém exemplos inacabados ou teorias sobre a linguagem que podem vir a ser interessantes.

Feito por <a href="https://www.linkedin.com/in/volnei-neves">Volnei Neves</a> :wave:
