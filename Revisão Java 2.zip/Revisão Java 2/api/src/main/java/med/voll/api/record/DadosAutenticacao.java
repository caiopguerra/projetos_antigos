package med.voll.api.record;

public record DadosAutenticacao(String login, String senha) {

}
