<?php 
	//esse é o edit.php
	include('functions.php'); 
	edit(); //mudei aqui
	include(HEADER_TEMPLATE);
?>

		<header>
			<h2>Atualizar Movel</h2>
		</header>

		<form action="edit.php?id=<?php echo $movel['id']; ?>" method="post">
			<!-- area de campos do form -->
			<hr>
				<div class="row">
					<div class="form-group col-md-8">
						<label for="name">Movel</label>
						<input type="text" class="form-control" name="movel[nome]" value="<?php echo $movel['nome']; ?>">
					</div>
					
					<div class="form-group col-md-4">
						<label for="campo2">Quantidade</label>
						<input type="text" class="form-control" name="movel[quatidade]" value="<?php echo $movel['quatidade']; ?>">
					</div>
				</div>
				<div class="row">
					<?php
						$foto = "";
						if (empty($movel['foto'])){
							$foto = "semimagem.jpg";
						} else{
							$foto = $movel['foto'];
						}
					?>
					<div class="form-group col-md-4">
						<label for="campo1">Foto</label>
						<input type="file" class="form-control" id= "foto" name="foto" value="fotos/<?php echo $foto ?>">
					</div>
					<div class="form-group col-md-2">
						<label for="campo1">Pré-visualização:</label>
						<img class="form-control shadow p-2 mb-2 bg-body rounded" id="imgPreview" src="fotos/<?php echo $foto ?>" alt="Foto do movel">
					</div>
				</div>
					
			<div id="actions" class="row">
				<div class="col-md-12">
					<button type="submit" class="btn btn-secondary"><i class="fa-solid fa-sd-card"></i> Salvar</button>
					<a href="index.php" class="btn btn-light"><i class="fa-solid fa-rotate-left"></i> Cancelar</a>
				</div>
			</div>
		</form>

<?php include(FOOTER_TEMPLATE); ?>

<script>
	$(document).ready(() => {
		$("#foto").change(function () {
			const file = this.files[0];
			if (file) {
				let reader = new FileReader();
				reader.onload = function (event) {
					$("#imgPreview").attr("src", event.target.result);
				};
				reader.readAsDataURL(file);
			}
		});
	});
</script>