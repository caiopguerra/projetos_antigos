<?php
	
	require_once('../config.php');
	require_once(DBAPI);
	//include('../inc/fpdf.php');
	include('../inc/pdf.php');

	$movel = null;
	$movels = null;

	/**
	 *  Listagem de Movel
	 */
	function index() {
		global $movel;
		$movel = find_all('movel');
	}
		


	 /*  Upload de imagens
	 */
	function upload($pasta_destino, $arquivo_destino, $tipo_arquivo, $nome_temp, $tamanho_arquivo) {
		/*
		==> Upload de arquivos no PHP
		https://www.w3schools.com/php/php_file_upload.asp
		*/
		// Upload da foto
		try {
			$nomearquivo = basename($arquivo_destino); //nome do arquivo
			$uploadOk = 1;
			// Verificando se o arquivo é uma imagem
			if(isset($_POST["sumbmit"])) {
				$check = getimagesize ($nome_temp);
				if($check == false) {
					$_SESSION['message'] = "File is an image -" . $check["mime"] . ".";
					$_SESSION['type'] = "info";
					//echo "File is an image -" .$check["mime"] . ".";
					$uploadOk = 1;
				} else {
					$uploadOk = 0;
					throw new Exception("O arquivo não é uma imagem!");
					//echo "O arquivo não é uma imagem";
				}
			}
			
			//Verificando se o arquivo já existe na pasta
			if (file_exists($arquivo_destino)) {
				$uploadOk = 0;
				throw new Exception("Desculpe, o arquivo já existe!");
				//echo "Desculpe, o arquivo já existe.";
			}
			
			//Verificamdo se o tamanho de arquivo
			if ($tamanho_arquivo > 5000000) {
				$uploadOk = 0;
				throw new Exception("Desculpe, mas o é muito grande!");
				//echo "Desculpe, mas o arquivo é muitogrande!");
			}
			
			// Allow certain file formas
			if($tipo_arquivo != "jpg" && $tipo_arquivo != "png" && $tipo_arquivo != "jpeg" && $tipo_arquivo != "gif") {
				$uploadOk = 0;
				throw new Exception("Desculpe, mas só são permitidos arquivos de imagem JPEG, JPEG, PNG e GIF!");
				//echo"Desculpe, mas só são permitidos arquivo imagem JPG, JPEG, PNG e GIF!";			
			}
			
			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
				throw new Exception("Desculpe, mas o arquivo não pode ser enviado.");
				//echo "Desculpe, mas o arquivo não pode ser enviado.";
			} else {
				// Se tudo estiver OK, tentamos fazer o upload do arquivo
				if (move_uploaded_file($_FILES["foto"] ["tmp_name"], $arquivo_destino)) {
					//colocando o nome do arquivo da foto do usuario no vetor
					$_SESSION['message'] = "O arquivo" . htmlspecialchars($nomearquivo) . " foi armazenado.";
					$_SESSION['type'] = "success";
					//echo "O arquivo" . htmlspecialchars($nomearquivo) . " foi armazenado.";
				} else {
					throw new Exception("Desculpe, mas o arquivo não pode ser enviado.");
					//echo "Desculpe, mas o arquivo não pode ser enviado.";
				}
			}
		} catch (Exception $e) {
			$_SESSION['message'] = "Aconteceu um erro: " . $e->getMessage();
			$_SESSION['type'] = "danger";
		}
	  
	}
	
	/**
	 *	Cadastro de Movel
	 */
	function add() {
		if (!empty($_POST['movel'])) {
			try {
				$movel = $_POST['movel'];

				if (!empty($_FILES["foto"]["name"])) {
					// Upload da foto
					$pasta_destino = "fotos/"; // pasta onde ficam as fotos
					$arquivo_destino = $pasta_destino . basename($_FILES["foto"]["name"]); // Caminho completo até o arquivo que será arquivado
					$nomearquivo = basename($_FILES["foto"]["name"]); // nome do arquivo
					$resolucao_arquivo = getimagesize($_FILES["foto"]["tmp_name"]);
					$tamanho_arquivo = $_FILES["foto"]["size"]; // tamanho do arquivo em bytes
					$nome_temp = $_FILES["foto"]["tmp_name"]; // nome e caminho do arquivo no servidor
					$tipo_arquivo = strtolower(pathinfo($arquivo_destino, PATHINFO_EXTENSION)); // extensão do arquivo

					// Chamada da função upload para gravar a imagem
					upload($pasta_destino, $arquivo_destino, $tipo_arquivo, $nome_temp, $tamanho_arquivo);

					$movel['foto'] = $nomearquivo;
				}

				save('movel', $movel);
				header('Location: index.php');
			} catch (Exception $e) {
				$_SESSION['message'] = "Aconteceu um erro: " . $e->getMessage();
				$_SESSION['type'] = "danger";
			}
		}
	}
	
	/**
	 *  Atualizacao/Edicao de Movel
	 */
	function edit() {
		
		//$now = new DateTime ("now");
		try {
			if (isset($_GET['id'])) {
				
				$id = $_GET['id'];
				
				if (isset($_POST['movel'])) {
					
					$movel = $_POST['movel'];
					
					//criptografando a senha
					if (!empty($movel['password'])) {
						$senha = criptografia($movel['password']);
						$movel['password'] = $senha;
					}
					
					if (!empty($_FILES["foto"] ["name"])) {
						// Upload da foto
						$pasta_destino = "fotos/"; //pasta onde ficam as fotos
						$arquivo_destino = $pasta_destino . basename($_FILES["foto"] ["name"]); //Caminho completo até o arquivo que será gravado
						$nomearquivo = basename($_FILES["foto"] ["name"]); //nome do arquivo
						$resolucao_arquivo  = getimagesize($_FILES["foto"] ["tmp_name"]);
						$tamanho_arquivo = $_FILES["foto"] ["size"]; //tamanho do arquivo em bytes
						$nome_temp = $_FILES["foto"] ["tmp_name"];// nome e caminho do arquivo no servidor
						$tipo_arquivo = strtolower(pathinfo($arquivo_destino,PATHINFO_EXTENSION));// extensão do arquivo
						
						upload ($pasta_destino, $arquivo_destino, $tipo_arquivo, $nome_temp, $tamanho_arquivo);
						
						$movel['foto'] = $nomearquivo;
					}
					
					update('movel', $id, $movel);
					header('Location: index.php');
				} else {
					global $movel;
					$movel = find("movel", $id);
				}
			} else {
				header("Location: index.php");
			}
		} catch (Exception $e) {
			$_SESSION['message'] = "Aconteceu um erro: " . $e->getMessage();
			$_SESSION['type'] = "danger";
		}
	}
	
	/**
	*  Visualização de um Usuários
	*/
	function view($id = null) {
		global $movel;
		$movel = find('movel', $id);
		
	}
	/**
	 *  Exclusão de um Movel
	 */
	function delete($id = null) {

		global $movel;
		$movel = remove("movel", $id);
  
		header("location: index.php");
	  }
	 
	/**
	* Gerando PDF
	*/
	function pdf($p = null) {
		// Instanciar a classe de PDF
		$pdf = new PDF();
		$pdf->AliasNbPages();
		$pdf->AddPage();
		$pdf->SetFont('Times', '', 12);
		$movels = null; // Renomeie a variável para evitar conflito
	
		// Obter os dados dos móveis
		if ($p) {
			$movels = filter("movel", " nome like '%" . $p . "%'");
		} else {
			$movels = find_all("movel");
		}
	
		// Cabeçalho da tabela
		$pdf->Cell(38, 10, 'ID', 1, 0, 'C');
		$pdf->Cell(75, 10, 'Nome', 1, 0, 'C');
		$pdf->Cell(40, 10, 'Quantidade', 1, 0, 'C');
		$pdf->Cell(40, 10, 'Foto', 1, 1, 'C'); // Nova célula para a coluna de Foto
	
		// Preencher a tabela com os dados dos móveis
		foreach ($movels as $movel) {
			$pdf->Cell(38, 35, $movel['id'], 1, 0, 'C');
			$pdf->Cell(75, 35, $movel['nome'], 1, 0, 'C');
			$pdf->Cell(40, 35, $movel['quatidade'], 1, 0, 'C');
	
			// Verificar se há uma foto definida
			if (!empty($movel['foto'])) {
				$foto_path = "fotos/" . $movel['foto']; // Caminho para a foto
				if (file_exists($foto_path)) {
					$pdf->Image($foto_path, $pdf->GetX()+8, $pdf->GetY()+5, 25); // Inserir a imagem
				}
			} else {
				$pdf->Cell(40, 35, "Sem foto", 1, 0, 'C'); // Se não houver foto, exibe "Sem foto"
			}
	
			$pdf->Ln(); // Nova linha para o próximo móvel
		}
	
		$pdf->Output();
	}
?>
