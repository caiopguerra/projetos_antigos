<?php
	
	require_once('../config.php');
	require_once(DBAPI);
	//include('../inc/fpdf.php');
	include('../inc/pdf.php');

	$customers = null;
	$customer = null;

	/**
	 *  Listagem de Clientes
	 */
	function index() {
		global $customers;
		$customers = find_all('customers');
	}
		
		/**
	 *  Visualização de um Cliente
	 */
	function view($id = null) {
	  global $customer;
	  $customer = find('customers', $id);
	}
	/**
	 *  Cadastro de Clientes
	 */
	function add() {

		if (!empty($_POST['customer'])) {
			
			$today = date_create('now', new DateTimeZone('America/Sao_Paulo'));
	
			$customer = $_POST['customer']; // Corrigido para 'customer'
			$customer['modified'] = $customer['created'] = $today->format("Y-m-d H:i:s");
			
			save('customers', $customer);
			header('location: index.php');
			
		}
	}
	

	
	/**
	 *	Atualizacao/Edicao de Cliente
	 */
	function edit() {

	  $now = date_create('now', new DateTimeZone('America/Sao_Paulo'));

	  if (isset($_GET['id'])) {

		$id = $_GET['id'];

		if (isset($_POST['customer'])) {

		  $customer = $_POST['customer'];
		  $customer['modified'] = $now->format("Y-m-d H:i:s");

		  update('customers', $id, $customer);
		  header('location: index.php');
		} else {

		  global $customer;
		  $customer = find('customers', $id);
		} 
	  } else {
		header('location: index.php');
	  }
	}
	
	/**
	 *  Exclusão de um Cliente
	 */
	function delete($id = null) {

	  global $customer;
	  remove('customers', $id);

	  header('location: index.php');
	}
	
	/**
	* Gerando PDF
	*/
	function pdf($p = null) {
		// Instanciar a classe de PDF
		$pdf = new PDF();
		$pdf->AliasNbPages();
		$pdf->AddPage();
		$pdf->SetFont('Arial', '', 12);
	
		// Definir larguras das colunas
		$column_widths = array(10, 30, 30, 30, 40, 35); // Ajuste conforme os campos desejados
	
		// Definir cabeçalhos da tabela
		$headers = array(
			'ID',
			'Nome',
			'CPF/CNPJ',
			'Telefone',
			'Endereço',
			'Modificado'
		);
	
		// Obter os dados dos clientes
		if ($p) {
			$customers = filter("customers", " nome like '%" . $p . "%'");
		} else {
			$customers = find_all("customers");
		}
	
		// Imprimir cabeçalhos da tabela
		$pdf->SetFillColor(220, 220, 220); // Cor de fundo das células do cabeçalho
		$pdf->SetTextColor(0); // Cor do texto
		$pdf->SetDrawColor(128, 128, 128); // Cor das linhas
		$pdf->SetFont('Arial', 'B', 10);
		for ($i = 0; $i < count($headers); $i++) {
			$pdf->Cell($column_widths[$i], 10, $headers[$i], 1, 0, 'C', true);
		}
		$pdf->Ln(); // Nova linha após o cabeçalho
	
		// Imprimir dados dos clientes
		$pdf->SetFont('Arial', '', 10);
		foreach ($customers as $customer) {
			$pdf->Cell($column_widths[0], 15, $customer['id'], 1, 0, 'C');
			$pdf->Cell($column_widths[1], 15, $customer['name'], 1, 0, 'L');
			$pdf->Cell($column_widths[2], 15, $customer['cpf_cnpj'], 1, 0, 'L');
			$pdf->Cell($column_widths[3], 15, formatacel($customer['phone']), 1, 0, 'C'); // Utilizando função formatacel para formatar telefone
			$pdf->Cell($column_widths[4], 15, $customer['address'], 1, 0, 'L');
			$pdf->Cell($column_widths[5], 15, formatadata($customer['modified'], 'd/m/Y H:i:s'), 1, 0, 'C'); // Utilizando função formatadata para formatar data
			$pdf->Ln(); // Nova linha após cada cliente
		}
	
		// Saída do PDF
		$pdf->Output();
	}
	
	function formatacel($cel) {
        $cl = substr($cel, 0, 0) . "(" . substr($cel, 0, 2) . ")" . " " . substr($cel, 2, 5) . "-" . substr($cel, 7, 12);
        return $cl;
    }
	
	function formatadata($data, $formato) {
         $dt = new DateTime($data, new DateTimeZone("America/Sao_Paulo"));
         return $dt->format($formato);
    }
	
	function formatacep ($cep) {
        $cp = substr($cep, 0, 8);
        return $cp;
    }
?>