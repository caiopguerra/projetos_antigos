<?php
	function open_database() {
		try {
			$conn = new PDO("mysql:host=". DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8", DB_USER, DB_PASSWORD);
			$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			return $conn;
		} catch (Exception $e) {
			throw new Exception($e->getMessage());
		}
	}
	
	function close_database($conn) {
		$conn = null;
	}

	function find($table = null, $id = null) {
		$database = open_database();
		$found = null;
		try {
			if ($id) {
				// Consulta preparada para buscar um registro pelo ID
				$sql = "SELECT * FROM $table WHERE id = ?";
				$stmt = $database->prepare($sql);
				$stmt->execute([$id]);
				$found = $stmt->fetch(PDO::FETCH_ASSOC);
			} else {
				// Consulta para buscar todos os registros da tabela
				$sql = "SELECT * FROM $table";
				$stmt = $database->query($sql);
				$found = $stmt->fetchAll(PDO::FETCH_ASSOC);
			}
		} catch (PDOException $e) {
			// Captura e trata exceções relacionadas ao banco de dados
			$_SESSION['message'] = $e->getMessage();
			$_SESSION['type'] = 'danger';
		}
		// Fecha a conexão com o banco de dados
		close_database($database);
		return $found;
	}

	function find_all($table) {
		return find($table);
	}

	/**
	 *  Atualiza um registro em uma tabela, por ID
	 */
	function update($table = null, $id = 0, $data = null) {
		try {
			$database = open_database();
	
			$items = '';
			
			$items = rtrim($items, ',');
	
			$sql = "UPDATE $table SET $items WHERE id=?";
			$stmt = $database->prepare($sql);
	
			$values[] = $id;
	
			$stmt->execute($values);
	
			$_SESSION['message'] = "Registro atualizado com sucesso.";
			$_SESSION['type'] = "success";
		} catch (PDOException $e) {
			$_SESSION['message'] = "Não foi possível realizar a operação.";
			$_SESSION['type'] = "danger";
		}
	}
	function remove($table = null, $id = null) {
		try {
			if (!$table || !$id) {
				throw new Exception("Parâmetros inválidos para a exclusão.");
			}
			
			$database = open_database();
	
			// Preparar e executar a consulta de exclusão
			$sql = "DELETE FROM $table WHERE id = ?";
			$stmt = $database->prepare($sql);
			$stmt->bindParam(1, $id, PDO::PARAM_INT);
			$stmt->execute();
	
			// Verificar se a exclusão foi bem-sucedida
			if ($stmt->rowCount() > 0) {
				$_SESSION['message'] = "Registro removido com sucesso.";
				$_SESSION['type'] = "success";
			} else {
				$_SESSION['message'] = "Nenhum registro encontrado para exclusão.";
				$_SESSION['type'] = "warning";
			}
	
		} catch (PDOException $e) {
			$_SESSION['message'] = "Erro ao executar a exclusão: " . $e->getMessage();
			$_SESSION['type'] = 'danger';
		} catch (Exception $e) {
			$_SESSION['message'] = $e->getMessage();
			$_SESSION['type'] = 'danger';
		}
	}
	
		
	function clear_messages() {
		$_SESSION['message'] = null;
		$_SESSION['type'] = null;
	}

	/**
	 * Pesquisa registros pelo parametro $p que foi passado
	 */
	function filter( $table = null, $p = null ) {
		
		$database = open_database();
		$found = null;
		
		try {
			if ($p) {
				$sql = "SELECT * FROM " . $table . " WHERE " . $p;
				$result = $database->query($sql);
				if ($result->num_rows > 0) {
					$found = array();
					while ($row = $result->fetch_assoc()) {
						array_push($found, $row);
					}
				} else {
					throw new Exception("Não foram encontrados registros de dados!");
				}
			}
		} catch (Exception $e) {
			$_SESSION['message'] = "Ocorreu um erro:" . $e->GetMessage();
			$_SESSION['type'] = "danger";
		}
		
		close_database($database);
		return $found;
	}
	
	function criptografia($senha) {
		$custo = '08';
		$salt = 'Cf1f11ePArKlBJomM0F6aJ';
		
		$hash = crypt($senha, '$2a$' . $custo . '$' . $salt . '$');
	
		return $hash;
	}
	
	/**
	*  Insere um registro no BD
	*/
	function save($table = null, $data = null) {

		$database = open_database();
  
		$columns = null;
		$values = null;
  
		//print_r($data);
  
		foreach ($data as $key => $value) {
		  $columns .= trim($key, "'") . ",";
		  $values .= "'$value',";
		}
  
		// remove a ultima virgula
		$columns = rtrim($columns, ',');
		$values = rtrim($values, ',');
		
		$sql = "INSERT INTO " . $table . "($columns)" . " VALUES " . "($values);";
  
		try {
		  $database->query($sql);
  
		  $_SESSION['message'] = "Registro cadastrado com sucesso.";
		  $_SESSION['type'] = "success";
		
		} catch (Exception $e) { 
		
		  $_SESSION['message'] = "Nao foi possivel realizar a operacao.";
		  $_SESSION['type'] = "danger";
		} 
  
		close_database($database);
	}
	function find_by_name($table, $name) {
		$database = open_database();
		$name = "%$name%"; // Adiciona curingas '%' antes e depois do nome
		$sql = "SELECT * FROM $table WHERE nome LIKE :name";
		$stmt = $database->prepare($sql);
		$stmt->bindParam(':name', $name, PDO::PARAM_STR);
		$stmt->execute();
		$found = $stmt->fetchAll(PDO::FETCH_ASSOC);
		close_database($database);
		return $found;
	}
?>