# Kame House Shop - API's

Esta é a documentação para a API da Loja de Produtos Eletrônicos **Kame House Shop**. A aplicação foi desenvolvida para gerenciar clientes, funcionários, pedidos, produtos, categorias e autenticação JWT. Esta API permite que você realize operações de criação, leitura, atualização e exclusão (CRUD) para todas as entidades mencionadas.

This is the documentation for the API of the Kame House Shop Electronic Products Store. The application was developed to manage customers, employees, orders, products, categories, and JWT authentication. This API allows you to perform create, read, update, and delete (CRUD) operations for all the mentioned entities.

## Index

- [Autenticação JWT](#autenticação-jwt)
- [Endpoints](#endpoints)  
- [Clientes](#customers)
- [Funcionários](#employees)
- [Pedidos](#orders)
- [Produtos](#products)
- [Categorias](#categories)  

## Technologies:

- [Sprint Tool Suite 4](https://spring.io/tools)
- [Postgres](https://www.postgresql.org/download/)
- [Dbeaver](https://dbeaver.io/download/)
- [Postman](https://www.postman.com/downloads/)
- [Insomnia](https://insomnia.rest/download)
- [Swagger](https://swagger.io/tools/swagger-ui/download/)
- [Java 17](https://www.oracle.com/java/technologies/javase/jdk17-archive-downloads.html) 
- [Hibernate](https://hibernate.org)
- [JPA](https://openjpa.apache.org/downloads.html)

## Autenticação JWT

A API utiliza a autenticação JWT (JSON Web Tokens) para garantir a segurança das rotas. Para acessar as rotas protegidas, você precisará enviar um token JWT válido no cabeçalho da requisição HTTP. O token JWT deve ser obtido através da rota de autenticação, fornecendo credenciais válidas.

## Endpoints

A seguir, estão listados os principais endpoints da API:

- Endpoint: `/clientes/all`
  - Método: GET
  - Descrição: Retorna todos os usuários cadastrados.
  - Resposta: Uma lista de objetos do tipo Usuário.

- Endpoint: `/clientes/Cliente/{id}`
  - Método: GET
  - Descrição: Retorna o usuário correspondente ao ID fornecido.
  - Parâmetro de Path: id (ID do cliente)
  - Resposta: Um objeto do tipo Cliente.

- Endpoint: `/clientes/Cliente/add`
  - Método: POST
  - Descrição: Adiciona um novo cliente.
  - Corpo da solicitação: Um objeto do tipo Cliente contendo as informações do cliente a ser adicionado.
  - Resposta: Um objeto do tipo Cliente representando o usuário adicionado.

- Endpoint: `/cliente/Cliente/delete/{clienteId}`
  - Método: DELETE
  - Descrição: Remove o cliente correspondente ao ID fornecido.
  - Parâmetro de Path: usuarioId (ID do usuário)
  - Resposta: Um objeto do tipo Cliente representando o cliente removido.

- Endpoint: `/clientes/Clientes/edit/{clienteId}`
  - Método: PUT
  - Descrição: Atualiza as informações do cliente correspondente ao ID fornecido.
  - Parâmetros de Path:
    - usuarioId (ID do cliente)
  - Parâmetros de Consulta:
    - firstname (primeiro nome do cliente)
    - lastname (sobrenome do cliente)
    - cpf (CPF do cliente)
    - email (e-mail do cliente)
  - Resposta: Um objeto do tipo Cliente representando o cliente atualizado.

- Endpoint: `/produtos/all`
  - Método: GET
  - Descrição: Retorna todos os produtos cadastrados.
  - Resposta: Uma lista de objetos do tipo Produto.

- Endpoint: `/produtos/produto/{id}`
  - Método: GET
  - Descrição: Retorna o produto correspondente ao ID fornecido.
  - Parâmetro de Path: id (ID do produto)
  - Resposta: Um objeto do tipo Produto.

- Endpoint: `/produtos/produto/add`
  - Método: POST
  - Descrição: Adiciona um novo produto.
  - Corpo da solicitação: Um objeto do tipo Produto contendo as informações do produto a ser adicionado.
  - Resposta: Um objeto do tipo Produto representando o produto adicionado.

- Endpoint: `/produtos/produto/delete/{id}`
  - Método: DELETE
  - Descrição: Remove o produto correspondente ao ID fornecido.
  - Parâmetro de Path: id (ID do produto)
  - Resposta: Um objeto do tipo Produto representando o produto removido.

- Endpoint: `/produtos/produto/edit/{produtoId}`
  - Método: PUT
  - Descrição: Atualiza as informações do produto correspondente ao ID fornecido
  - Parâmetros de Path:    
  - produtoId (ID do produto)    
  - Parâmetros de Consulta:    
  - nome  
  - descrição
  - valor
  - Resposta: Um objeto do tipo Produto representando o produto atualizado.

- Endpoint: `/funcionarios/all`
  - Método: GET
  - Descrição: Retorna todos os funcionários cadastrados.
  - Resposta: Uma lista de objetos do tipo Funcionario.

- Endpoint: `/funcionarios/funcionario/{id}`
  - Método: GET
  - Descrição: Retorna o funcionário correspondente ao ID fornecido.
  - Parâmetro de Path: id (ID do funcionário)
  - Resposta: Um objeto do tipo Funcionario.

- Endpoint: `/funcionarios/funcionarios/add`
  - Método: POST
  - Descrição: Adiciona um novo funcionário.
  - Corpo da solicitação: Um objeto do tipo Funcionario contendo as informações do funcionário a ser adicionado.
  - Resposta: Um objeto do tipo Funcionario representando o funcionário adicionado.

- Endpoint: `/funcionarios/funcionario/delete/{id}`
  - Método: DELETE
  - Descrição: Remove o funcionário correspondente ao ID fornecido.
  - Parâmetro de Path: id (ID do funcionário)
  - Resposta: Um objeto do tipo Funcionario representando o funcionário removido.

- Endpoint: `/funcionarios/funcionario/edit/{funcionarioId}`
  - Método: PUT
  - Descrição: Atualiza as informações do funcionário correspondente ao ID fornecido.
  - Parâmetros de Path:
    - funcionarioId (ID do funcionário)
  - Parâmetros de Consulta:
    - nome (nome do funcionário)
  - Resposta: Um objeto do tipo Funcionario representando o funcionário atualizado.  

# Review  
Here is a quick summary of the entire API documentation for a general understanding of what has been described.

## Authentication
- [POST /auth/login](#post-authlogin): Performs user login and returns a valid JWT token for subsequent authentication.

## Customers

  - GET /customers: Returns the list of all registered customers.
  - GET /customers/{id}: Returns the details of a specific customer.
  - POST /customers: Creates a new customer.
  - PUT /customers/{id}: Updates the data of a specific customer.
  - DELETE /customers/{id}: Deletes a specific customer.

## Employees

  - GET /employees: Returns the list of all registered employees.
  - GET /employees/{id}: Returns the details of a specific employee.
  - POST /employees: Creates a new employee.
  - PUT /employees/{id}: Updates the data of a specific employee.
  - DELETE /employees/{id}: Deletes a specific employee.

## Orders

  - GET /orders: Returns the list of all registered orders.
  - GET /orders/{id}: Returns the details of a specific order.
  - POST /orders: Creates a new order.
  - PUT /orders/{id}: Updates the data of a specific order.
  - DELETE /orders/{id}: Deletes a specific order.

## Products

  - GET /products: Returns the list of all registered products.
  - GET /products/{id}: Returns the details of a specific product.
  - POST /products: Creates a new product.
  - PUT /products/{id}: Updates the data of a specific product.
  - DELETE /products/{id}: Deletes a specific product.

## Categories

  - GET /categories: Returns the list of all registered categories.
  - GET /categories/{id}: Returns the details of a specific category.
  - POST /categories: Creates a new category.
  - PUT /categories/{id}: Updates the data of a specific category.
  - DELETE /categories/{id}: Deletes a specific category.

**The API uses request parameters that are sent in the body of the HTTP request in JSON format.**


## Autores:  
[Bernardo Alves](https://github.com/Boyce22)   
[Caio Guerra](https://github.com/caioguerra27k)  
[Maria E. Ribeiro](https://github.com/xmariaeduardaribeiro)  
[Rafael Vieira](https://github.com/RafaelVieiraCamara)  

## Professora:
[Débora Souza](https://github.com/debysouza)  
