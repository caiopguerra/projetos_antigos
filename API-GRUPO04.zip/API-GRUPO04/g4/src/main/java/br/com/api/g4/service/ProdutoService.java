package br.com.api.g4.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.api.g4.domain.Categoria;
import br.com.api.g4.domain.Produto;
import br.com.api.g4.dto.ProdutoCreateDTO;
import br.com.api.g4.dto.ProdutoEditDTO;
import br.com.api.g4.dto.ProdutoFindDTO;
import br.com.api.g4.exceptions.NotFoundExeception;
import br.com.api.g4.repository.CategoriaRepository;
import br.com.api.g4.repository.ProdutoRepository;
import jakarta.mail.MessagingException;

@Service
public class ProdutoService {

	@Autowired
	ProdutoRepository produtoRepository;
	
	@Autowired
	CategoriaRepository categoriaRepository;

	@Autowired
	EmailService emailService;

	public List<ProdutoFindDTO> findAll() {
		return produtoRepository.findAll().stream().map(ProdutoFindDTO::new).toList();
	}

	public ProdutoFindDTO getById(Long produtoId) {
		Produto produto = produtoRepository.findById(produtoId)
				.orElseThrow(() -> new NotFoundExeception("Produto não encontrado"));
		return new ProdutoFindDTO(produto);
	}

	public Produto addProduto(ProdutoCreateDTO produtoDTO, String email) throws MessagingException {
	    Produto novoProduto = new Produto();
	    novoProduto.setNome(produtoDTO.getNomeProduto());
	    novoProduto.setValor(produtoDTO.getValor());
	    novoProduto.setDescricao(produtoDTO.getDescricaoProduto());
	    novoProduto.setEstoque(produtoDTO.getEstoque());

	    Categoria categoria = categoriaRepository.findById(produtoDTO.getCategoriaId())
	            .orElseThrow(() -> new NotFoundExeception("Categoria não encontrada"));

	    novoProduto.setCategoria(categoria);

	    Produto produtoSalvo = produtoRepository.save(novoProduto);
	    emailService.confirmacaoCadastroProduto(email, produtoSalvo);

	    return produtoSalvo;
	}

	public Produto deleteProduto(Long produtoId) {
		Produto produto = produtoRepository.findById(produtoId)
				.orElseThrow(() -> new NotFoundExeception("Produto não encontrado"));

		produto.setIsActive(false); // DELETE LÓGICO
		return produtoRepository.save(produto);
	}

	public Produto editProduto(Long produtoId, ProdutoEditDTO produtoDTO) {
		Produto produtoExistente = produtoRepository.findById(produtoId).orElse(null);
		if (produtoExistente != null) {
			produtoExistente.setNome(produtoDTO.getNomeProduto());
			produtoExistente.setValor(produtoDTO.getValor());
			produtoExistente.setDescricao(produtoDTO.getDescricaoProduto());
			produtoExistente.setEstoque(produtoDTO.getEstoque());
			return produtoRepository.save(produtoExistente);
		}
		return null;
	}
}
