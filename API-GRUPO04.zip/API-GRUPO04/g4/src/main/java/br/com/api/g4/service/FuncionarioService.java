package br.com.api.g4.service;

import java.util.List;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.api.g4.domain.Funcionario;
import br.com.api.g4.dto.FuncionarioDTO;
import br.com.api.g4.exceptions.NotFoundExeception;
import br.com.api.g4.repository.FuncionarioRepository;

@Service
public class FuncionarioService {

	@Autowired
	FuncionarioRepository funcionarioRepository;

	public List<Funcionario> findAll() {
		return funcionarioRepository.findAll();
	}

	public Funcionario getById(Long funcionarioId) {
		Optional<Funcionario> funcionarioOptional = funcionarioRepository.findById(funcionarioId);
		return funcionarioOptional.orElseThrow(() -> new NotFoundExeception ("Funcionario não encontrado"));
	}

	public Funcionario addFuncionario(Funcionario novoFuncionario) {
		return funcionarioRepository.save(novoFuncionario);
	}

	public Funcionario deleteFuncionario(Long funcionarioId) {
		Funcionario funcionario = getById(funcionarioId);
		if (funcionario != null) {
			funcionario.setIsActive(false);
			return funcionario;
		}
		return null;
	}

	public Funcionario editFuncionario(Long funcionarioId, String firstName, String lastName, String cpf) {
		Funcionario funcionario = getById(funcionarioId);
		if (funcionario != null) {
			funcionario.setFirstName(firstName);
			funcionario.setLastName(lastName);
			funcionario.setCpf(cpf);
			// Long funcId, String firstName, String lastName, String cpf
			return funcionarioRepository.save(funcionario);
		}
		return null;
	}
	
	//CRUD com DTO.
	
	public FuncionarioDTO getByIdDto(Long funcionarioId) {
		Funcionario funcionario = funcionarioRepository.findById(funcionarioId)
		.orElseThrow(() -> new NotFoundExeception ("Funcionario não encontrado"));
		return new FuncionarioDTO(funcionario);
	}

	public FuncionarioDTO addFuncionarioDto(Funcionario funcionario) {
		return new FuncionarioDTO(funcionario);
	}

	public Funcionario deleteFuncionarioDto(Long funcionarioId) {
		Funcionario funcionario = getById(funcionarioId);
		if (funcionario != null) {
			funcionario.setIsActive(false);
			return funcionario;
		}
		return null;
	}

	public FuncionarioDTO editFuncionarioDto(Long funcionarioId, String firstName, String lastName, String cpf) {
		Funcionario funcionario = getById(funcionarioId);
		if (funcionario != null) {
			funcionario.setFirstName(firstName);
			funcionario.setLastName(lastName);
			funcionario.setCpf(cpf);
			// Long funcId, String firstName, String lastName, String cpf
			return new FuncionarioDTO(funcionario);
		}
		return null;
	}

}
