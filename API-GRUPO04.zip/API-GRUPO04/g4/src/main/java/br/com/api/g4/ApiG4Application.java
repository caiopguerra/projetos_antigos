package br.com.api.g4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiG4Application {

	public static void main(String[] args) {
		SpringApplication.run(ApiG4Application.class, args);
	}

}
