package br.com.api.g4.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.api.g4.domain.Cliente;
import br.com.api.g4.domain.Pedido;
import br.com.api.g4.dto.PedidoCreateDTO;
import br.com.api.g4.dto.PedidoDeleteReturnDTO;
import br.com.api.g4.dto.PedidoEditDTO;
import br.com.api.g4.dto.PedidoFindDTO;
import br.com.api.g4.dto.PedidoReturnDTO;
import br.com.api.g4.exceptions.NotFoundExeception;
import br.com.api.g4.repository.ClienteRepository;
import br.com.api.g4.repository.PedidoRepository;

@Service
public class PedidoService {

	@Autowired
	private PedidoRepository pedidoRepository;

	@Autowired
	ClienteRepository clienteRepository;

	public List<PedidoFindDTO> findAll() {
		return pedidoRepository.findAll().stream().map(PedidoFindDTO::new).toList();
	}

	public PedidoFindDTO getById(Long pedidoId) {
		Pedido pedido = pedidoRepository.findById(pedidoId)
				.orElseThrow(() -> new NotFoundExeception("Pedido não encontrado"));
		return new PedidoFindDTO(pedido);
	}

	public PedidoReturnDTO addPedido(PedidoCreateDTO pedidoDTO) {
		Pedido novoPedido = new Pedido();
		novoPedido.setNumeroPedido(pedidoDTO.getNumeroPedido());
		novoPedido.setDescricaoPedido(pedidoDTO.getDescricaoPedido());
		novoPedido.setValorPedido(pedidoDTO.getValorPedido());

		Cliente cliente = clienteRepository.findById(pedidoDTO.getClienteId())
				.orElseThrow(() -> new NotFoundExeception("Pedido não encontrado"));

		novoPedido.setCliente(cliente);

		Pedido pedido = pedidoRepository.save(novoPedido);

		PedidoReturnDTO pedidoReturnDTO = new PedidoReturnDTO();
		pedidoReturnDTO.setNumeroPedido(pedido);
		pedidoReturnDTO.setDescricaoPedido(pedido);
		pedidoReturnDTO.setValorPedido(pedido);
		pedidoReturnDTO.setCliente(cliente);

		return pedidoReturnDTO;
	}

	public PedidoDeleteReturnDTO deletePedido(Long pedidoId) {
		Pedido pedido = pedidoRepository.findById(pedidoId)
				.orElseThrow(() -> new NotFoundExeception("Pedido não encontrado"));

		pedido.setIsActive(false); // DELETE LÓGICO
		pedidoRepository.save(pedido);

		PedidoDeleteReturnDTO pedidoDeleteReturnDTO = new PedidoDeleteReturnDTO();
		pedidoDeleteReturnDTO.setCliente(pedido.getCliente());
		pedidoDeleteReturnDTO.setNumeroPedido(pedido);
		pedidoDeleteReturnDTO.setDescricaoPedido(pedido);
		pedidoDeleteReturnDTO.setValorPedido(pedido);
		pedidoDeleteReturnDTO.setIsActive(pedido.getIsActive());

		return pedidoDeleteReturnDTO;
	}

	public PedidoReturnDTO editPedido(Long pedidoId, PedidoEditDTO pedidoDTO) {
		Pedido pedidoExistente = pedidoRepository.findById(pedidoId)
				.orElseThrow(() -> new NotFoundExeception("Pedido não encontrado"));

		pedidoExistente.setNumeroPedido(pedidoDTO.getNumeroPedido());
		pedidoExistente.setDescricaoPedido(pedidoDTO.getDescricaoPedido());
		pedidoExistente.setValorPedido(pedidoDTO.getValorPedido());
		Pedido pedidoAtualizado = pedidoRepository.save(pedidoExistente);

		PedidoReturnDTO pedidoReturnDTO = new PedidoReturnDTO();
		pedidoReturnDTO.setNumeroPedido(pedidoAtualizado);
		pedidoReturnDTO.setDescricaoPedido(pedidoAtualizado);
		pedidoReturnDTO.setValorPedido(pedidoAtualizado);
		pedidoReturnDTO.setCliente(pedidoAtualizado.getCliente());

		return pedidoReturnDTO;

	}

}
