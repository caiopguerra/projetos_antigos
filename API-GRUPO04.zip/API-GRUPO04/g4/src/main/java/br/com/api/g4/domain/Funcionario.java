package br.com.api.g4.domain;

import br.com.api.g4.security.domain.User;
import jakarta.annotation.Nullable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table (name = "funcionario")
public class Funcionario {
	
	@Id
	@GeneratedValue (strategy= GenerationType.IDENTITY)
	@Column(name = "func_cd_id")
	private Long funcId;

	@Nullable
	@Column(name = "func_tx_firstName")
	private String firstName;

	@Nullable
	@Column(name = "func_tx_lastName")
	private String lastName;

	@Nullable
	@Column(name = "func_tx_cpf")
	private String cpf;

	@Nullable
	@Column(name = "func_bl_isActive")
	private Boolean isActive;
	
	@OneToOne
	@JoinColumn(name = "fk_user_cd_id", referencedColumnName = "id")
	private User user;

	public Funcionario () {
		
	}	

	public Funcionario(Long funcId, String firstName, String lastName, String cpf, Boolean isActive) {
		super();
		this.funcId = funcId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.cpf = cpf;
		this.isActive = isActive;
	}

	public Long getFuncId() {
		return funcId;
	}

	public void setFuncId(Long funcId) {
		this.funcId = funcId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	
	
}