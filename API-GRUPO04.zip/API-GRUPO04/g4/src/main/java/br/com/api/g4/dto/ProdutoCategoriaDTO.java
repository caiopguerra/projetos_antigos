package br.com.api.g4.dto;

public class ProdutoCategoriaDTO {

	private String nomeProduto;

	private Double valor;

	private String nomeCategoria;

	private String descricaoProduto;

	private String descricaoCategoria;

	public ProdutoCategoriaDTO(String nomeProduto, Double valor, String nomeCategoria, String descricaoProduto,
			String descricaoCategoria) {
		this.nomeProduto = nomeProduto;
		this.valor = valor;
		this.nomeCategoria = nomeCategoria;
		this.descricaoProduto = descricaoProduto;
		this.descricaoCategoria = descricaoCategoria;
	}

	public String getNomeProduto() {
		return nomeProduto;
	}

	public void setNomeProduto(String nomeProduto) {
		this.nomeProduto = nomeProduto;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

	public String getNomeCategoria() {
		return nomeCategoria;
	}

	public void setNomeCategoria(String nomeCategoria) {
		this.nomeCategoria = nomeCategoria;
	}

	public String getDescricaoProduto() {
		return descricaoProduto;
	}

	public void setDescricaoProduto(String descricaoProduto) {
		this.descricaoProduto = descricaoProduto;
	}

	public String getDescricaoCategoria() {
		return descricaoCategoria;
	}

	public void setDescricaoCategoria(String descricaoCategoria) {
		this.descricaoCategoria = descricaoCategoria;
	}

}
