package br.com.api.g4.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.api.g4.domain.Imagem;

public interface ImagemRepository extends JpaRepository<Imagem, Long>{

}
