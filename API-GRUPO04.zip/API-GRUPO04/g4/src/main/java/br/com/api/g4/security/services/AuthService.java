package br.com.api.g4.security.services;

public class AuthService {

}
