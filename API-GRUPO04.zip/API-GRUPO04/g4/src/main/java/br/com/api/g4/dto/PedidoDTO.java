package br.com.api.g4.dto;

public class PedidoDTO {

}
