package br.com.api.g4.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.api.g4.domain.Categoria;
import br.com.api.g4.dto.CategoriaDTO;
import br.com.api.g4.dto.CategoriaDeleteDTO;
import br.com.api.g4.exceptions.NotFoundExeception;
import br.com.api.g4.repository.CategoriaRepository;

@Service
public class CategoriaService {
	
	@Autowired
	private CategoriaRepository categoriaRepository;
	
	public List<CategoriaDTO> findAll() {
		return categoriaRepository.findAll().stream().map(CategoriaDTO::new).toList();
	}
	
	public CategoriaDTO getById(Long categoriaId) {
		Categoria categoria = categoriaRepository.findById(categoriaId).
		orElseThrow(() -> new NotFoundExeception("Categoria não encontrada"));
		return new CategoriaDTO(categoria);
	}

	
	
	public CategoriaDTO addCategoria (Categoria novaCategoria) {
		return new CategoriaDTO(novaCategoria);
	}
	
	public CategoriaDeleteDTO deleteCategoria(Long categoriaId) {
		Categoria categoria = new Categoria();
		categoria.getCategoriaId();
		if (categoria != null) {
			categoria.setIsActive(false);
			categoriaRepository.save(categoria);
		}
		return new CategoriaDeleteDTO(categoria);
	}
	
	
	public CategoriaDTO editCategoria (Long categoriaId, String nomeCategoria, String descricaoCategoria) {
		Categoria categoria = new Categoria();
		categoria.getCategoriaId();
		if (categoria != null) {
			categoria.setNomeCategoria(nomeCategoria);
			categoria.setDescricaoCategoria(descricaoCategoria);
			categoriaRepository.save(categoria);
		}
		return new CategoriaDTO(categoria);
	}
	
}
