package br.com.api.g4.dto;

import java.util.Set;

import br.com.api.g4.domain.Cliente;

public class ClienteDTO {

		private String firstName;
		private String lastName;
		private String cpf;
		private String cep;
		private String birthDate;
		private String passaword;
		private Set<String> roles;
		private String url;

		public ClienteDTO(Cliente cliente) {
			this.firstName = cliente.getFirstName();
			this.lastName = cliente.getLastName();
			this.cpf = cliente.getCpf();
			this.birthDate = cliente.getBirthDate();
			this.cep = cliente.getCep();
		}

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		public String getCpf() {
			return cpf;
		}

		public void setCpf(String cpf) {
			this.cpf = cpf;
		}

		public String getBirthDate() {
			return birthDate;
		}

		public void setBirthDate(String birthDate) {
			this.birthDate = birthDate;
		}

		public String getCep() {
			return cep;
		}

		public void setCep(String cep) {
			this.cep = cep;
		}
}
	