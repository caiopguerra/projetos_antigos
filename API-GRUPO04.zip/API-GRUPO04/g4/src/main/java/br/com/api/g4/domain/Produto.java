package br.com.api.g4.domain;

import jakarta.annotation.Nullable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "produto")
public class Produto {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "prod_cd_id")
    private Long produtoId;

    @Nullable
    @Column(name = "prod_tx_nome")
    private String nomeProduto;

    @Nullable
    @Column(name = "prod_tx_desc")
    private String descricaoProduto;

    @Column(name = "prod_int_quant")
    private Integer estoque;

    @Nullable
    @Column(name = "prod_tx_valor")
    private Double valor;

    // DELETE LOGICO
    @Nullable
    @Column(name = "prod_bl_isactive")
    private Boolean isActive = true;

    @ManyToOne
    @JoinColumn(name = "categoria_id")
    private Categoria categoria;

    public Produto() {

    }

    public Produto(Long produtoId, String nomeProduto, String descricaoProduto, Integer estoque, Double valor, Boolean isActive, Categoria categoria) {
        this.produtoId = produtoId;
        this.nomeProduto = nomeProduto;
        this.descricaoProduto = descricaoProduto;
        this.estoque = estoque;
        this.valor = valor;
        this.isActive = isActive;
        this.categoria = categoria;
    }

    public Long getProdutoId() {
        return produtoId;
    }

    public void setProdutoId(Long produtoId) {
        this.produtoId = produtoId;
    }

    public String getNomeProduto() {
        return nomeProduto;
    }

    public void setNome(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }

    public String getDescricaoProduto() {
        return descricaoProduto;
    }

    public void setDescricao(String descricaoProduto) {
        this.descricaoProduto = descricaoProduto;
    }

    public Integer getEstoque() {
        return estoque;
    }

    public void setEstoque(Integer estoque) {
        this.estoque = estoque;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }
}
