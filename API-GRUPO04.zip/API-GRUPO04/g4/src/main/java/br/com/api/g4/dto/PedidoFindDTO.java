package br.com.api.g4.dto;

import java.util.Date;

import br.com.api.g4.domain.Pedido;

public class PedidoFindDTO {

	private Long id;
	
	private String numeroPedido;
	
	private String descricaoPedido;
	
	private String valorPedido;
	
	private Date dataPedido;

	public PedidoFindDTO(Long id, String numeroPedido, String descricaoPedido, String valorPedido, Date dataPedido) {
		this.id = id;
		this.numeroPedido = numeroPedido;
		this.descricaoPedido = descricaoPedido;
		this.valorPedido = valorPedido;
		this.dataPedido = dataPedido;
	}

	public PedidoFindDTO(Pedido pedido) {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNumeroPedido() {
		return numeroPedido;
	}

	public void setNumeroPedido(Pedido pedido) {
		this.numeroPedido = pedido.getNumeroPedido();
	}

	public String getDescricaoPedido() {
		return descricaoPedido;
	}

	public void setDescricaoPedido(Pedido pedido) {
		this.descricaoPedido = pedido.getDescricaoPedido();
	}

	public String getValorPedido() {
		return valorPedido;
	}

	public void setValorPedido(Pedido pedido) {
		this.valorPedido = pedido.getValorPedido();
	}

	public Date getDataPedido() {
		return dataPedido;
	}

	public void setDataPedido(Date dataPedido) {
		this.dataPedido = dataPedido;
	}
	
	
	
	

	
	
}
