package br.com.api.g4.dto;

import br.com.api.g4.domain.Cliente;
import br.com.api.g4.domain.Pedido;

public class PedidoCreateDTO {

	private Long clienteId;

	private String numeroPedido;

	private String descricaoPedido;

	private String valorPedido;

	public PedidoCreateDTO(String numeroPedido, String descricaoPedido, String valorPedido, Long clienteId) {
		this.numeroPedido = numeroPedido;
		this.descricaoPedido = descricaoPedido;
		this.valorPedido = valorPedido;

		this.clienteId = clienteId;
	}

	public PedidoCreateDTO() {
	}

	public String getNumeroPedido() {
		return numeroPedido;
	}

	public void setNumeroPedido(Pedido pedido) {
		this.numeroPedido = pedido.getNumeroPedido();
	}

	public String getDescricaoPedido() {
		return descricaoPedido;
	}

	public void setDescricaoPedido(Pedido pedido) {
		this.descricaoPedido = pedido.getDescricaoPedido();
	}

	public String getValorPedido() {
		return valorPedido;
	}

	public void setValorPedido(Pedido pedido) {
		this.valorPedido = pedido.getValorPedido();
	}

	public Long getClienteId() {
		return clienteId;
	}

	public void setClienteId(Cliente cliente) {
		this.clienteId = cliente.getClienteId();
	}

}
