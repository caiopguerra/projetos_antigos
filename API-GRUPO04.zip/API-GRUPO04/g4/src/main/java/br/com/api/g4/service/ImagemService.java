package br.com.api.g4.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import br.com.api.g4.domain.Cliente;
import br.com.api.g4.domain.Funcionario;
import br.com.api.g4.domain.Imagem;
import br.com.api.g4.repository.ImagemRepository;

@Service
public class ImagemService {
    @Autowired
    ImagemRepository imagemRepository;

    @Autowired
    FuncionarioService funcionarioService;

    @Autowired
    ClienteService clienteService;

    public Imagem cadastrarImagemCliente(MultipartFile imagem, Cliente cliente) throws IOException {

        Imagem imagemCliente = new Imagem();
        imagemCliente.setDados(imagem.getBytes());
        imagemCliente.setTipo(imagem.getContentType());
        imagemCliente.setNome(imagem.getOriginalFilename());
        imagemCliente.setCliente(cliente);
        return imagemRepository.save(imagemCliente); 
        }

    public Imagem cadastrarImagemFuncionario(MultipartFile imagem, Funcionario funcionario) throws IOException {
          Imagem imagemFuncionario = new Imagem();
          imagemFuncionario.setFuncionario(funcionario);
          imagemFuncionario.setDados(imagem.getBytes());
          imagemFuncionario.setTipo(imagem.getContentType());
          imagemFuncionario.setNome(imagem.getOriginalFilename());
          return imagemRepository.save(imagemFuncionario);
    }
}
