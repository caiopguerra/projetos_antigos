package br.com.api.g4.dto;

public class ClienteEnderecoTelefoneDTO {

	private String firstName;

	private String lastName;

	private String cpf;

	private String birthDate;

	private String cep;

	private String logradouro;

	private String uf;

	private String numero;

	private String numCelular;

	private String numTelefone;

	public ClienteEnderecoTelefoneDTO(String firstName, String lastName, String cpf, String birthDate, String cep,
			String logradouro, String uf, String numero, String numCelular, String numTelefone) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.cpf = cpf;
		this.birthDate = birthDate;
		this.cep = cep;
		this.logradouro = logradouro;
		this.uf = uf;
		this.numero = numero;
		this.numCelular = numCelular;
		this.numTelefone = numTelefone;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getNumCelular() {
		return numCelular;
	}

	public void setNumCelular(String numCelular) {
		this.numCelular = numCelular;
	}

	public String getNumTelefone() {
		return numTelefone;
	}

	public void setNumTelefone(String numTelefone) {
		this.numTelefone = numTelefone;
	}

}
