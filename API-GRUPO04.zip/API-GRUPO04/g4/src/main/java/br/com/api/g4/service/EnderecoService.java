package br.com.api.g4.service;

import br.com.api.g4.domain.Endereco;
import br.com.api.g4.exceptions.NotFoundExeception;
import br.com.api.g4.repository.EnderecoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;

@Service
public class EnderecoService {

	@Autowired
	EnderecoRepository enderecoRepository;

	public EnderecoService(EnderecoRepository enderecoRepository) {
		this.enderecoRepository = enderecoRepository;
	}

	public List<Endereco> getAllEnderecos() {
		return enderecoRepository.findAll();
	}

	public Endereco getEnderecoById(Integer id) {
		Optional<Endereco> optionalEndereco = enderecoRepository.findById(id);
		return optionalEndereco.orElseThrow(() -> new NotFoundExeception ("Endereco não encontrado"));
	}

	public Endereco createEndereco(String cep, String numero) {
	    String uri = "http://viacep.com.br/ws/{cep}/json";
	    RestTemplate restTemplate = new RestTemplate();
	    Endereco viaCepResponse = restTemplate.getForObject(uri, Endereco.class, cep);

	    if (viaCepResponse != null) {
	        Endereco endereco = new Endereco();
	        endereco.setCep(viaCepResponse.getCep());
	        endereco.setLogradouro(viaCepResponse.getLogradouro());
	        endereco.setBairro(viaCepResponse.getBairro());
	        endereco.setLocalidade(viaCepResponse.getLocalidade());
	        endereco.setUf(viaCepResponse.getUf());
	        endereco.setNumero(numero);
	        return enderecoRepository.save(endereco);
	    }
		return null;
	}
	public Endereco editEndereco(Integer id, Endereco endereco) {
		Optional<Endereco> optionalEndereco = enderecoRepository.findById(id);
		if (optionalEndereco.isPresent()) {
			Endereco existingEndereco = optionalEndereco.get();
			existingEndereco.setCep(endereco.getCep());
			existingEndereco.setLogradouro(endereco.getLogradouro());
			existingEndereco.setBairro(endereco.getBairro());
			existingEndereco.setLocalidade(endereco.getLocalidade());
			existingEndereco.setUf(endereco.getUf());
			existingEndereco.setNumero(endereco.getNumero());
			return enderecoRepository.save(existingEndereco);
		} else {
			return null;
		}
	}

	public void deleteEndereco(Integer id) {
		enderecoRepository.deleteById(id);
	}
}
