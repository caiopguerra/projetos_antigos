package br.com.api.g4.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.api.g4.dto.PedidoCreateDTO;
import br.com.api.g4.dto.PedidoDeleteReturnDTO;
import br.com.api.g4.dto.PedidoEditDTO;
import br.com.api.g4.dto.PedidoFindDTO;
import br.com.api.g4.dto.PedidoReturnDTO;
import br.com.api.g4.service.PedidoService;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/pedidos")
public class PedidoController {

    @Autowired
    PedidoService pedidoService;

    @GetMapping("/all")
    public List<PedidoFindDTO> findAll() {
        return pedidoService.findAll();
    }

    @GetMapping("/find/{pedidoId}")
    public PedidoFindDTO findPedido(@PathVariable Long pedidoId) {
        return pedidoService.getById(pedidoId);
    }

    @PostMapping("/add")
    public PedidoReturnDTO addPedido(@Valid @RequestBody PedidoCreateDTO pedidoDTO) {
        return pedidoService.addPedido(pedidoDTO);
    }

    @PutMapping("/edit/{pedidoId}")
    public PedidoReturnDTO editPedido(@PathVariable Long pedidoId, @Valid @RequestBody PedidoEditDTO pedidoDTO) {
        return pedidoService.editPedido(pedidoId, pedidoDTO);
    }

    @DeleteMapping("/delete/{pedidoId}")
    public PedidoDeleteReturnDTO deletePedido(@PathVariable Long pedidoId) {
        return pedidoService.deletePedido(pedidoId);
    }
}
