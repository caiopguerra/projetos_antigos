package br.com.api.g4.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Telefone")
public class Telefone {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "tel_cd_id")
	private Long telefoneId;

	@Column(name = "tel_tx_cel")
	private String numCelular;

	@Column(name = "tel_tx_tel")
	private String numTelefone;

	public Telefone() {

	}

	public Telefone(Long telefoneId, String numCelular, String numTelefone) {
		this.telefoneId = telefoneId;
		this.numCelular = numCelular;
		this.numTelefone = numTelefone;
	}

	public Long getTelefoneId() {
		return telefoneId;
	}

	public void setTelefoneId(Long telefoneId) {
		this.telefoneId = telefoneId;
	}

	public String getNumCelular() {
		return numCelular;
	}

	public void setNumCelular(String numCelular) {
		this.numCelular = numCelular;
	}

	public String getNumTelefone() {
		return numTelefone;
	}

	public void setNumTelefone(String numTelefone) {
		this.numTelefone = numTelefone;
	}

}
