package br.com.api.g4.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.api.g4.domain.Produto;
import br.com.api.g4.dto.ProdutoCreateDTO;
import br.com.api.g4.dto.ProdutoEditDTO;
import br.com.api.g4.dto.ProdutoFindDTO;
import br.com.api.g4.service.EmailService;
import br.com.api.g4.service.ProdutoService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.mail.MessagingException;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/produtos")
public class ProdutoController {

	@Autowired
	ProdutoService produtoService;

	@Autowired
	EmailService emailService;

	@GetMapping("/all")
	public List<ProdutoFindDTO> findAll() {
		return produtoService.findAll();
	}

	@GetMapping("/find/{produtoId}")
	public ProdutoFindDTO findProduto(@PathVariable Long produtoId) {
		return produtoService.getById(produtoId);
	}

	@PostMapping("/add")
	@SecurityRequirement(name = "Bearer Auth")
	public Produto addProduto(@Valid @RequestParam String email, @RequestBody ProdutoCreateDTO produtoDTO)
			throws MessagingException {
		return produtoService.addProduto(produtoDTO, email);
	}

	@PutMapping("/edit/{produtoId}")
	public Produto editProduto(@PathVariable("produtoId") Long produtoId, @RequestBody ProdutoEditDTO produtoDTO) {
		return produtoService.editProduto(produtoId, produtoDTO);
	}

	@DeleteMapping("/delete")
	@SecurityRequirement(name = "Bearer Auth")
	@PreAuthorize("hasRole('FUNCIONARIO')")
	public Produto deleteProduto(@RequestParam Long produtoId) {
		return produtoService.deleteProduto(produtoId);
	}

}
