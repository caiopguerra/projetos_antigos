package br.com.api.g4.dto;

import br.com.api.g4.domain.Produto;

public class ProdutoFindDTO {

	private Long produtoId;

	private String nomeProduto;

	private String descricaoProduto;

	private Integer estoque;

	private Double valor;

	public ProdutoFindDTO(Long produtoId, String nomeProduto, String descricaoProduto, Integer estoque, Double valor) {
		this.produtoId = produtoId;
		this.nomeProduto = nomeProduto;
		this.descricaoProduto = descricaoProduto;
		this.estoque = estoque;
		this.valor = valor;
	}

	public ProdutoFindDTO(Produto produto) {

	}

	public Long getProdutoId() {
		return produtoId;
	}

	public void setProdutoId(Produto produto) {
		this.produtoId = produto.getProdutoId();
	}

	public String getNomeProduto() {
		return nomeProduto;
	}

	public void setNomeProduto(Produto produto) {
		this.nomeProduto = produto.getNomeProduto();
	}

	public String getDescricaoProduto() {
		return descricaoProduto;
	}

	public void setDescricaoProduto(Produto produto) {
		this.descricaoProduto = produto.getDescricaoProduto();
	}

	public Integer getEstoque() {
		return estoque;
	}

	public void setEstoque(Produto produto) {
		this.estoque = produto.getEstoque();
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Produto produto) {
		this.valor = produto.getValor();
	}

}
