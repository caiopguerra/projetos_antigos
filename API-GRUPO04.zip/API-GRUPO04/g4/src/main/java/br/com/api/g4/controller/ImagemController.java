//package br.com.api.g4.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import br.com.api.g4.service.ClienteService;
//import br.com.api.g4.service.FuncionarioService;
//import br.com.api.g4.service.ImagemService;
//
//@RestController
//@RequestMapping("/imagem")
//public class ImagemController {
//
//    @Autowired
//    ImagemService imagemService;
//
//    @Autowired
//    FuncionarioService funcionarioService;
//
//    @Autowired
//    ClienteService clienteService;
//
//    @PostMapping("/imagem-funcionario-cliente")
//    @SecurityRequirement(name ="")
//    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
////    @Operation(summary = "Inserir a imagem no banco de dados - ADM e USER", description)
//}
