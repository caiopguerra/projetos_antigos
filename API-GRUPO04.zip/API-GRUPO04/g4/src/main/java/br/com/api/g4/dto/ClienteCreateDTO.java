package br.com.api.g4.dto;

public class ClienteCreateDTO {
    private Long clienteId;
    private String firstName;
    private String lastName;
    private String cpf;
    private String birthDate;
    private String cep;

    public ClienteCreateDTO() {
    }

    public ClienteCreateDTO(Long clienteId, String firstName, String lastName, String cpf, String birthDate, String cep) {
        this.clienteId = clienteId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.cpf = cpf;
        this.birthDate = birthDate;
        this.cep = cep;
    }

    public Long getClienteId() {
        return clienteId;
    }

    public void setClienteId(Long clienteId) {
        this.clienteId = clienteId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }
}
