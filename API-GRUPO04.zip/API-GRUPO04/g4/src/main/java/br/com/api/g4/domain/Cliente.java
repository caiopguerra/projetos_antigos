package br.com.api.g4.domain;

import br.com.api.g4.security.domain.User;
import jakarta.annotation.Nullable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import java.util.List;

@Entity
@Table(name = "Cliente")
public class Cliente {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "cli_cd_id")
	private Long clienteId;

	@Nullable
	@Column(name = "cli_tx_firstName")
	private String firstName;

	@Nullable
	@Column(name = "cli_tx_lastName")
	private String lastName;
	
	@Nullable
	@Column(name = "cli_tx_cep")
	private String cep;

	@Nullable
	@Column(name = "cli_tx_cpf")
	private String cpf;

	@Nullable
	@Column(name = "cli_tx_birthDate")
	private String birthDate;

	@Nullable
	@Column(name = "cli_bl_isActive")
	private Boolean isActive;

	@ManyToOne
	@JoinColumn(name = "fk_cli_end_id", referencedColumnName = "enderecoid")
	private Endereco endereco;

	@OneToOne
	@JoinColumn(name = "fk_user_cd_id", referencedColumnName = "id")
	private User user;

	@OneToOne
	@JoinColumn(name = "telefone_id")
	private Telefone telefone;

	@OneToMany(mappedBy = "cliente")
	private List<Pedido> pedidos;

	public Cliente() {

	}

	public Cliente(Long clienteId, String firstName, String lastName, String cpf, String birthDate, Boolean isActive,
			Endereco endereco, User user, String cep) {
		this.clienteId = clienteId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.cpf = cpf;
		this.birthDate = birthDate;
		this.cep = cep;
		this.isActive = isActive;
		this.endereco = endereco;
		this.user = user;
	}

	public Long getClienteId() {
		return clienteId;
	}

	public void setClienteId(Long clienteId) {
		this.clienteId = clienteId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<Pedido> getPedidos() {
		return pedidos;
	}

	public void setPedidos(List<Pedido> pedidos) {
		this.pedidos = pedidos;
	}

	public Telefone getTelefone() {
		return telefone;
	}

	public void setTelefone(Telefone telefone) {
		this.telefone = telefone;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}
}
