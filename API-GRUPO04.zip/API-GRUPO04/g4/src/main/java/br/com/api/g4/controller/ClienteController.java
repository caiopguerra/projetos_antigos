package br.com.api.g4.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.api.g4.domain.Cliente;
import br.com.api.g4.dto.ClienteDTO;
import br.com.api.g4.dto.ClienteDeleteDTO;
import br.com.api.g4.service.ClienteService;
import br.com.api.g4.service.EmailService;
import jakarta.mail.MessagingException;

//import br.com.api.g4.service.EmailService;
//import jakarta.mail.MessagingException;

@RestController
@RequestMapping("/clientes")
public class ClienteController {

	@Autowired
	private ClienteService clienteService;

	@Autowired
	private EmailService emailService;

	@GetMapping("/all")
	public List<ClienteDTO> findAll() {
		return clienteService.findAll();
	}

	@GetMapping("/find/{clienteId}")
	public ClienteDTO findUsuario(@RequestParam Long clienteId) {
		return clienteService.getById(clienteId);
	}

	@PostMapping("/add")
	public ClienteDTO addUsuario(@RequestParam String email, @RequestBody Cliente novoCliente) throws MessagingException {
		ClienteDTO cliente = clienteService.addCliente(novoCliente);
		emailService.envioEmailCadastro(email, novoCliente);
		return cliente;
	}

	@DeleteMapping("/delete")
	public ClienteDeleteDTO deleteUsuario(@RequestParam String email, @RequestParam Long clienteId) throws MessagingException {
		ClienteDeleteDTO cliente = clienteService.deleteCliente(clienteId);
		emailService.envioEmailDelete(email, clienteId, cliente);
		return clienteService.deleteCliente(clienteId);
	}

	@PutMapping("/edit")
	public ClienteDTO editUsuario(@RequestParam Long clienteId, @RequestParam String firstname,
			@RequestParam String lastname, @RequestParam String cpf, @RequestParam String cep) {
		return clienteService.editCliente(clienteId, firstname, lastname, cpf, cep);
	}
}
