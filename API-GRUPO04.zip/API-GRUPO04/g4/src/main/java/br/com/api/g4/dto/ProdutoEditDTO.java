package br.com.api.g4.dto;

import br.com.api.g4.domain.Produto;

public class ProdutoEditDTO {
	
	private Long pordutoId;

	private String nomeProduto;
	
	private Double valor;
	
	private String descricaoProduto;
	
	private Integer estoque;

	public ProdutoEditDTO(Long pordutoId, String nomeProduto, Double valor, String descricaoProduto, Integer estoque) {
		this.pordutoId = pordutoId;
		this.nomeProduto = nomeProduto;
		this.valor = valor;
		this.descricaoProduto = descricaoProduto;
		this.estoque = estoque;
	}

	public Long getPordutoId() {
		return pordutoId;
	}

	public void setPordutoId(Long pordutoId) {
		this.pordutoId = pordutoId;
	}

	public String getNomeProduto() {
		return nomeProduto;
	}

	public void setNomeProduto(Produto produto) {
		this.nomeProduto = produto.getNomeProduto();
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Produto produto) {
		this.valor = produto.getValor();
	}

	public String getDescricaoProduto() {
		return descricaoProduto;
	}

	public void setDescricaoProduto(Produto produto) {
		this.descricaoProduto = produto.getDescricaoProduto();
	}

	public Integer getEstoque() {
		return estoque;
	}

	public void setEstoque(Produto produto) {
		this.estoque = produto.getEstoque();
	}
	
	
	
	
}
