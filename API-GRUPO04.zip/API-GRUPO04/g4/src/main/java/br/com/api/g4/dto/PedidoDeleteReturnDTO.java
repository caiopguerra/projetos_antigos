package br.com.api.g4.dto;

import br.com.api.g4.domain.Cliente;
import br.com.api.g4.domain.Pedido;

public class PedidoDeleteReturnDTO {
	
	private String cliente;
	
	private String numeroPedido;

	private String descricaoPedido;

	private String valorPedido;
	
	private Boolean isActive;

	public String getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente.getFirstName() + " " + cliente.getLastName();
	}

	public String getNumeroPedido() {
		return numeroPedido;
	}

	public void setNumeroPedido(Pedido pedido) {
		this.numeroPedido = pedido.getNumeroPedido();
	}

	public String getDescricaoPedido() {
		return descricaoPedido;
	}

	public void setDescricaoPedido(Pedido pedido) {
		this.descricaoPedido = pedido.getDescricaoPedido();
	}

	public String getValorPedido() {
		return valorPedido;
	}

	public void setValorPedido(Pedido pedido) {
		this.valorPedido = pedido.getValorPedido();
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	
	

}
