package br.com.api.g4.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.api.g4.domain.Endereco;
import br.com.api.g4.service.EnderecoService;

@RestController
@RequestMapping("/enderecos")
public class EnderecoController {

	@Autowired
	EnderecoService enderecoService;

	public EnderecoController(EnderecoService enderecoService) {
		this.enderecoService = enderecoService;
	}

	@GetMapping
	public List<Endereco> getAllEnderecos() {
		return enderecoService.getAllEnderecos();
	}

	@GetMapping("/find")
	public Endereco getEnderecoById(@RequestParam("id") Integer id) {
		return enderecoService.getEnderecoById(id);
	}

	@PostMapping("/add")
	public Endereco createEndereco(@RequestParam("cep") String cep, @RequestParam String numero) {
	    return enderecoService.createEndereco(cep, numero);
	}

	@PutMapping("/edit")
	public Endereco editEndereco(@RequestParam("id") Integer id, @RequestBody Endereco endereco) {
		return enderecoService.editEndereco(id, endereco);
	}

	@DeleteMapping("/delete")
	public void deleteEndereco(@RequestParam("id") Integer id) {
		enderecoService.deleteEndereco(id);
	}
}
