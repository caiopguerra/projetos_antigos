package br.com.api.g4.repository;

import br.com.api.g4.domain.Endereco;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository("endereco")
public interface EnderecoRepository extends JpaRepository<Endereco, Integer> {
}
