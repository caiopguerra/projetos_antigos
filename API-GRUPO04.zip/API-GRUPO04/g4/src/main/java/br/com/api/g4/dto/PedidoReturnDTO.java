package br.com.api.g4.dto;

import br.com.api.g4.domain.Cliente;
import br.com.api.g4.domain.Pedido;

public class PedidoReturnDTO {
	
	private String cliente;
	
	private String numeroPedido;

	private String descricaoPedido;

	private String valorPedido;
	
	public PedidoReturnDTO() {
		
	}

	public PedidoReturnDTO(String numeroPedido, String descricaoPedido, String valorPedido, String cliente) {
		this.numeroPedido = numeroPedido;
		this.descricaoPedido = descricaoPedido;
		this.valorPedido = valorPedido;
		this.cliente = cliente;
	}

	public String getNumeroPedido() {
		return numeroPedido;
	}

	public void setNumeroPedido(Pedido pedido) {
		this.numeroPedido = pedido.getNumeroPedido();
	}

	public String getDescricaoPedido() {
		return descricaoPedido;
	}

	public void setDescricaoPedido(Pedido pedido) {
		this.descricaoPedido = pedido.getDescricaoPedido();
	}

	public String getValorPedido() {
		return valorPedido;
	}

	public void setValorPedido(Pedido pedido) {
		this.valorPedido = pedido.getValorPedido();
	}

	public String getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente.getFirstName() + " " + cliente.getLastName();
	}
	
	

}