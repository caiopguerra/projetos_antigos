package br.com.api.g4.enums;

public enum PessoasEnum {

	PESSOA_CLIENTE("Cliente", 1), PESSOA_FUNCIONARIO("Funcionario", 2);

	private String tipo;
	private int codigo;

	private PessoasEnum(String tipo, int codigo) {
		this.tipo = tipo;
		this.codigo = codigo;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	
	
	
}