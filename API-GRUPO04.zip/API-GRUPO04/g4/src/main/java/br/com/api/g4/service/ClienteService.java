package br.com.api.g4.service;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;


import br.com.api.g4.domain.Cliente;
import br.com.api.g4.domain.Endereco;
import br.com.api.g4.dto.ClienteDTO;
import br.com.api.g4.dto.ClienteDeleteDTO;
import br.com.api.g4.exceptions.NotFoundExeception;
import br.com.api.g4.repository.ClienteRepository;
import br.com.api.g4.repository.EnderecoRepository;
//import br.com.api.g4.security.domain.User;
//import br.com.api.g4.service.EmailService;
//import jakarta.mail.MessagingException;

@Service
public class ClienteService {

	@Autowired
	private ClienteRepository clienteRepository;
	
	@Autowired
	private EnderecoRepository enderecoRepository;

	public List<ClienteDTO> findAll() {
		return clienteRepository.findAll().stream().map(ClienteDTO::new).toList();
	}

	public ClienteDTO getById(Long clienteId) {
		Cliente cliente = clienteRepository.findById(clienteId).
		orElseThrow (() -> new NotFoundExeception("Cliente não encontrado"));
		return new ClienteDTO(cliente);
	}

	public ClienteDTO addCliente(Cliente novoCliente) {
	    RestTemplate restTemplate = new RestTemplate();
	    String uri = "http://viacep.com.br/ws/{cep}/json";
	    Map<String, Object> params = new HashMap<>();
	    params.put("cep", novoCliente.getCep());
	    Endereco viaCepResponse = restTemplate.getForObject(uri, Endereco.class, params);

	    Endereco endereco = new Endereco();
	    endereco.setCep(viaCepResponse.getCep());
	    endereco.setLogradouro(viaCepResponse.getLogradouro());
	    endereco.setBairro(viaCepResponse.getBairro());
	    endereco.setLocalidade(viaCepResponse.getLocalidade());
	    endereco.setUf(viaCepResponse.getUf());
	    endereco.setNumero(novoCliente.getEndereco().getNumero());

	    enderecoRepository.save(endereco);

	    novoCliente.setEndereco(endereco);

	    return new ClienteDTO(novoCliente);
	}



	public ClienteDeleteDTO deleteCliente(Long clienteId) {
		Cliente cliente = new Cliente();
		cliente.getClienteId();
		if (cliente != null) {
			cliente.setIsActive(false);
			clienteRepository.save(cliente);
		}
		return new ClienteDeleteDTO(cliente);
	}

	public ClienteDTO editCliente(Long clienteId, String firstName, String lastName, String cpf, String cep) {

		Cliente cliente = new Cliente();
		cliente.getClienteId();
		if (cliente != null) {
			cliente.setFirstName(firstName);
			cliente.setLastName(lastName);
			cliente.setCpf(cpf);
			cliente.setCep(cep);
			clienteRepository.save(cliente);
		}
		return new ClienteDTO(cliente);
	}

}