package br.com.api.g4.dto;

import java.util.Set;

import br.com.api.g4.domain.Funcionario;

public class FuncionarioDTO {

	private String firstName;
	private String lastName;
	private String cpf;
	private String passaword;
	private Set<String> roles;
	private String url;
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public FuncionarioDTO() {
		super();
	}

	public FuncionarioDTO(Funcionario funcionario) {
		super();
		this.firstName = funcionario.getFirstName();
		this.lastName = funcionario.getLastName();
		this.cpf = funcionario.getCpf();
	}

}
