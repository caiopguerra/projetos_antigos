package br.com.api.g4.service;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import br.com.api.g4.domain.Cliente;
import br.com.api.g4.domain.Produto;
import br.com.api.g4.dto.ClienteDeleteDTO;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Configuration
@Service
public class EmailService {

	@Autowired
	JavaMailSender emailSender;

	@Bean
	JavaMailSender javaMailSender() {
		JavaMailSenderImpl emailSender = new JavaMailSenderImpl();
		Properties properties = new Properties();
		emailSender.setHost("smtp.gmail.com");
		emailSender.setPort(587);
		emailSender.setUsername("grupo04.api@gmail.com");
		emailSender.setPassword("dcqpvomagoesisrp");
		properties.put("mail.smtp.auth", true); // Corrected property name
		properties.put("mail.smtp.starttls.enable", true); // Corrected property name
		emailSender.setJavaMailProperties(properties);

		return emailSender;

	}

	public void confirmacaoCadastroProduto(String email, Produto produto) throws MessagingException {
		this.emailSender = javaMailSender();
		MimeMessage messageProduto = emailSender.createMimeMessage();
		MimeMessageHelper helperProduto = new MimeMessageHelper(messageProduto, true);
		try {
			helperProduto.setFrom("grupo04.api@gmail.com");
			helperProduto.setTo(email);
			helperProduto.setSubject(email);
			StringBuilder sBuilder = new StringBuilder();
			sBuilder.append("<html>\r\n");
			sBuilder.append("   <head>\r\n");
			sBuilder.append("     <style>\r\n");
			sBuilder.append("       body {\r\n");
			sBuilder.append("         background-color: #8C52FF;\r\n");
			sBuilder.append("         color: #FFFFFF;\r\n");
			sBuilder.append("         font-family: Arial, sans-serif;\r\n");
			sBuilder.append("       }\r\n");
			sBuilder.append("       h1 {\r\n");
			sBuilder.append("         color: #000000;\r\n");
			sBuilder.append("       }\r\n");
			sBuilder.append("       p {\r\n");
			sBuilder.append("         color: #FFFFFF;\r\n");
			sBuilder.append("       }\r\n");
			sBuilder.append("       .container {\r\n");
			sBuilder.append("         background-color: #FFFFFF;\r\n");
			sBuilder.append("         padding: 20px;\r\n");
			sBuilder.append("         text-align: center;\r\n");
			sBuilder.append("         margin: 0 auto;\r\n");
			sBuilder.append("         width: 80%;\r\n");
			sBuilder.append("         max-width: 800px;\r\n");
			sBuilder.append("       }\r\n");
			sBuilder.append("     </style>\r\n");
			sBuilder.append("   </head>\r\n");
			sBuilder.append("   <body>\r\n");
			sBuilder.append("     <div class=\"container\">\r\n");
			sBuilder.append("       <h1>Cadastro Concluído com sucesso</h1>\r\n");
			sBuilder.append("       <p>ONome do Produto: " + produto.getNomeProduto());
			sBuilder.append("     </div>\r\n");
			sBuilder.append("   </body>\r\n");
			sBuilder.append("</html>\r\n");
			helperProduto.setText(sBuilder.toString(), true);
			emailSender.send(messageProduto);
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void envioEmailCadastro(String email, Cliente cliente) throws MessagingException {
		JavaMailSender javaMailSender = javaMailSender();
		MimeMessage messageCliente = javaMailSender.createMimeMessage();
		MimeMessageHelper helperCliente = new MimeMessageHelper(messageCliente, true);

		try {
			helperCliente.setFrom("grupo04.api@gmail.com"); // Corrected from email address
			helperCliente.setTo(email); // Corrected recipient email address
			helperCliente.setSubject("Cadastro Realizado");

			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("<html>\r\n");
			stringBuilder.append("	<body>\r\n");
			stringBuilder.append("		<div align=\"center\">\r\n");
			stringBuilder.append("			<h1>Cadastro Realizado</h1>\r\n");
			stringBuilder.append("		</div>\r\n");
			stringBuilder.append("		<br/>\r\n");
			stringBuilder.append("		<div>\r\n");
			stringBuilder.append("			Status: " + cliente.getIsActive() + "<br/>\r\n");
			stringBuilder.append("			Nome: " + cliente.getFirstName() + "<br/>\r\n");
			stringBuilder.append("			Sobrenome: " + cliente.getLastName() + "<br/>\r\n");
			stringBuilder.append("			Email: " + cliente.getUser().getEmail() + "<br/>\r\n");
			stringBuilder.append("			CPF: " + cliente.getCpf() + "<br/>\r\n");
			stringBuilder.append("		</div>\r\n");
			stringBuilder.append("	</body>\r\n");
			stringBuilder.append("</html>\r\n");

			helperCliente.setText(stringBuilder.toString(), true);
			javaMailSender.send(messageCliente);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void envioEmailDelete(String email, Long clienteId, ClienteDeleteDTO cliente) throws MessagingException {
		JavaMailSender javaMailSender = javaMailSender();
		MimeMessage messageCliente = javaMailSender.createMimeMessage();
		MimeMessageHelper helperCliente = new MimeMessageHelper(messageCliente, true);

		try {
			helperCliente.setFrom("grupo04.api@gmail.com"); // Corrected from email address
			helperCliente.setTo(email); // Corrected recipient email address
			helperCliente.setSubject("Obrigado por Utilizar os nosso Serviços! Até a próxima.");

			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("<html>\r\n");
			stringBuilder.append("	<body>\r\n");
			stringBuilder.append("		<div align=\"center\">\r\n");
			stringBuilder.append("			<h1>Cancelamento de Conta Realizado</h1>\r\n");
			stringBuilder.append("		</div>\r\n");
			stringBuilder.append("		<br/>\r\n");
			stringBuilder.append("		<div>\r\n");
			stringBuilder.append("			Nome: " + cliente.getFirstName() + "<br/>\r\n");
			stringBuilder.append("			Sobrenome: " + cliente.getLastName() + "<br/>\r\n");
			stringBuilder.append("			CPF: " + cliente.getCpf() + "<br/>\r\n");
			stringBuilder.append("		</div>\r\n");
			stringBuilder.append("	</body>\r\n");
			stringBuilder.append("</html>\r\n");

			helperCliente.setText(stringBuilder.toString(), true);
			javaMailSender.send(messageCliente);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	

}