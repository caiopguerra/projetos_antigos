package br.com.api.g4.dto;

import br.com.api.g4.domain.Categoria;

public class CategoriaDTO {

	private String nomeCategoria;
	private String descricaoCategoria;
	
	public String getNomeCategoria() {
		return nomeCategoria;
	}
	public void setNomeCategoria(String nomeCategoria) {
		this.nomeCategoria = nomeCategoria;
	}
	public String getDescricaoCategoria() {
		return descricaoCategoria;
	}
	public void setDescricaoCategoria(String descricaoCategoria) {
		this.descricaoCategoria = descricaoCategoria;
	}
	
	public CategoriaDTO(Categoria categoria) {
		super();
		this.nomeCategoria = categoria.getNomeCategoria();
		this.descricaoCategoria = categoria.getDescricaoCategoria();
	}
	
	public CategoriaDTO() {
		super();
	}
	
	
	
	
}
