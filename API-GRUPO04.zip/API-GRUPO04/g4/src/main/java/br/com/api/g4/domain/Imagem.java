 package br.com.api.g4.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "imagem")
public class Imagem {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "foto_cd_id")
	private Integer imagemId;

	@Lob
	@Column(name = "foto_tx_dados")
	private byte[] dados;

	@Column(name = "foto_tx_tipo")
	private String tipo;

	@Column(name = "foto_tx_nome")
	private String nome;

	@OneToOne
	@JoinColumn(name = "fk_cli_cd_id")
	private Cliente cliente;

	@OneToOne
	@JoinColumn(name = "fk_fun_cd_id")
	private Funcionario funcionario;
	
	public Integer getImagemId() {
		return imagemId;
	}

	public void setImagemId(Integer imagemId) {
		this.imagemId = imagemId;
	}

	public byte[] getDados() {
		return dados;
	}

	public void setDados(byte[] dados) {
		this.dados = dados;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Funcionario getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}


	public Imagem() {

	}

	public Imagem(Integer imagemId, byte[] dados, String tipo, String nome, Cliente cliente, Funcionario funcionario) {
		this.imagemId = imagemId;
		this.dados = dados;
		this.tipo = tipo;
		this.nome = nome;
		this.cliente = cliente;
		this.funcionario = funcionario;
	}

}
