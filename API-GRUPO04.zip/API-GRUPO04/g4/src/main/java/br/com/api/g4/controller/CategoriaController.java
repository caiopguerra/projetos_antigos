package br.com.api.g4.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.api.g4.domain.Categoria;
import br.com.api.g4.dto.CategoriaDTO;
import br.com.api.g4.dto.CategoriaDeleteDTO;
import br.com.api.g4.service.CategoriaService;
import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping("/categoria")
public class CategoriaController {

	@Autowired
	private CategoriaService categoriaService;

	@GetMapping("/all")
	public List<CategoriaDTO> findAll() {
		return categoriaService.findAll();
	}

	@GetMapping("/find/{categoriaId}")
	public CategoriaDTO findCategoria(@PathVariable Long categoriaId) {
		return categoriaService.getById(categoriaId);
	}

	@PostMapping("/add")
	public CategoriaDTO addCategoria(@RequestBody Categoria novaCategoria) {
		CategoriaDTO categoria = categoriaService.addCategoria(novaCategoria);

		return categoria;
	}

	@DeleteMapping("/delete")
	public CategoriaDeleteDTO deleteCategoria(@RequestParam Long categoriaId) {
		return categoriaService.deleteCategoria(categoriaId);
	}

	@PutMapping("/edit")
	public CategoriaDTO editCategoria(@PathVariable(value = "categoriaId") Long categoriaId,
			@RequestParam String nomeCategoria, @RequestParam String descricaoCategoria) {
		return categoriaService.editCategoria(categoriaId, nomeCategoria, descricaoCategoria);
	}

}
