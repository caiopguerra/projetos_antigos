package br.com.api.g4.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.api.g4.domain.Funcionario;
import br.com.api.g4.dto.FuncionarioDTO;
import br.com.api.g4.service.FuncionarioService;

@RestController
@RequestMapping("/funcionarios")
public class FuncionarioController {

	@Autowired
	FuncionarioService funcionarioService;

	@GetMapping("/all")
	public List<Funcionario> findAll() {
		return funcionarioService.findAll();
	}

	@GetMapping("/find/{id}")
	public FuncionarioDTO findFuncionario(@RequestParam Long funcionarioId) {
		return funcionarioService.getByIdDto(funcionarioId);
	}

	@PostMapping("/add")
	public FuncionarioDTO addFuncionario(@RequestBody Funcionario novoFuncionario) {
		return funcionarioService.addFuncionarioDto(novoFuncionario);
	}

	@DeleteMapping("/delete/{id}")
	public Funcionario deleteFuncionario(@RequestParam Long funcionarioId) {
		return funcionarioService.deleteFuncionario(funcionarioId);
	}

	@PutMapping("/edit/{funcionarioId}")
	public FuncionarioDTO editFuncionario(@RequestParam(value = "funcionarioId") Long funcionarioId,
			@RequestParam String firstName, String lastName, String cpf) {
		return funcionarioService.editFuncionarioDto(funcionarioId, firstName, lastName, cpf);
	}

}
