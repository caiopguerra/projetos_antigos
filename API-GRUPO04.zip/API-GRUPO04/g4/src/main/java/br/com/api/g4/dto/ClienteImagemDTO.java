package br.com.api.g4.dto;

public abstract class ClienteImagemDTO {


    private Integer imagemId;
    private byte[] dados;
    private String tipo;
    private String nome;
    private String cliente;

    public ClienteImagemDTO() {

    }

    public ClienteImagemDTO(Integer imagemId, byte[] dados, String tipo, String nome, String cliente) {
    	this.setImagemId(imagemId);
		this.setDados(dados);
		this.setTipo(tipo);
		this.setNome(nome);
		this.setCliente(cliente);

    }

	public Integer getImagemId() {
		return imagemId;
	}

	public void setImagemId(Integer imagemId) {
		this.imagemId = imagemId;
	}

	public byte[] getDados() {
		return dados;
	}

	public void setDados(byte[] dados) {
		this.dados = dados;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getCliente() {
		return cliente;
	}

	public void setCliente(String cliente) {
		this.cliente = cliente;
	}
    
//    public abstract void clienteImagemDTO(Cliente cliente); {
//    this.imagemId=cliente.getId();
//    this.tipo=cliente.getTipo();
//    this.nome=cliente.getNome();
//    this.dados=cliente.getDados();
//    }
	
}