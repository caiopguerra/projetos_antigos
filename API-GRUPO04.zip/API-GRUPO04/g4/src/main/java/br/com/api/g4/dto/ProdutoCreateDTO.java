package br.com.api.g4.dto;

import br.com.api.g4.domain.Categoria;
import br.com.api.g4.domain.Produto;

public class ProdutoCreateDTO{
	
	private String nomeProduto;
	
	private Double valor;
	
	private String descricaoProduto;
	
	private Integer estoque;
	
	private Long categoriaId;

	public ProdutoCreateDTO(String nomeProduto, Double valor, String descricaoProduto, Integer estoque, Long categoriaId) {
		this.nomeProduto = nomeProduto;
		this.valor = valor;
		this.descricaoProduto = descricaoProduto;
		this.estoque = estoque;
		this.categoriaId = categoriaId;
	}

	public String getNomeProduto() {
		return nomeProduto;
	}

	public void setNomeProduto(Produto produto) {
		this.nomeProduto = produto.getNomeProduto();
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Produto produto) {
		this.valor = produto.getValor();
	}

	public String getDescricaoProduto() {
		return descricaoProduto;
	}

	public void setDescricaoProduto(Produto produto) {
		this.descricaoProduto = produto.getDescricaoProduto();
	}

	public Integer getEstoque() {
		return estoque;
	}

	public void setEstoque(Produto produto) {
		this.estoque = produto.getEstoque();
	}

	public Long getCategoriaId() {
		return categoriaId;
	}

	public void setCategoriaId(Categoria categoria) {
		this.categoriaId = categoria.getCategoriaId();
	}
	
	
	
}