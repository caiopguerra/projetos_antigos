package br.com.api.g4.dto;

public class EnderecoDTO {

	private String cep;

	private String logradouro;

	private String uf;

	private String numero;

	public EnderecoDTO(String cep, String logradouro, String uf, String numero) {
		this.cep = cep;
		this.logradouro = logradouro;
		this.uf = uf;
		this.numero = numero;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}
}
