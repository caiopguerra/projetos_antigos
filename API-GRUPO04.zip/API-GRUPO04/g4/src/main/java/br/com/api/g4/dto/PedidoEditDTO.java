package br.com.api.g4.dto;

import br.com.api.g4.domain.Pedido;

public class PedidoEditDTO {

	private String numeroPedido;

	private String descricaoPedido;

	private String valorPedido;

	public PedidoEditDTO(String numeroPedido, String descricaoPedido, String valorPedido) {
		this.numeroPedido = numeroPedido;
		this.descricaoPedido = descricaoPedido;
		this.valorPedido = valorPedido;
	}

	public String getNumeroPedido() {
		return numeroPedido;
	}

	public void setNumeroPedido(Pedido pedido) {
		this.numeroPedido = pedido.getNumeroPedido();
	}

	public String getDescricaoPedido() {
		return descricaoPedido;
	}

	public void setDescricaoPedido(Pedido pedido) {
		this.descricaoPedido = pedido.getDescricaoPedido();
	}

	public String getValorPedido() {
		return valorPedido;
	}

	public void setValorPedido(Pedido pedido) {
		this.valorPedido = pedido.getValorPedido();
	}

}
